namespace RevisaoAula.paginas;

public partial class Texto : ContentPage
{
	public Texto()
	{
		InitializeComponent();

	}
   
    public void Voltar(object sender, EventArgs e)
    {
        App.Current.MainPage=new Page1();
    }
    private void input(object sender, TextChangedEventArgs e)
    {
        string textonovo = e.NewTextValue; 
        UpdateResultLabel(textonovo);
    }

    private void UpdateResultLabel(string textonovo)
    {
        string selectedOption = (string)casePicker.SelectedItem;

        if (selectedOption == "Caixa Alta")
        {
            resultado.Text = textonovo.ToUpper(); //uppercase
        }
        else if (selectedOption == "Caixa Baixa")
        {
            resultado.Text = textonovo.ToLower(); //lowercase
        }
    }
}