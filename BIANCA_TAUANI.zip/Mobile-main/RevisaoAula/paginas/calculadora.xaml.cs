namespace RevisaoAula.paginas;

public partial class calculadora : ContentPage
{
    public calculadora()
    {
        InitializeComponent();
    }
    public void Voltar(object sender, EventArgs e)
    {
        App.Current.MainPage = new Page1();
    }

    private void Calcular(object sender, EventArgs e)
    {
        if (double.TryParse(operador1.Text, out double firstOperand) &&
                double.TryParse(operador2.Text, out double secondOperand))
        {
            double result = 0;
            string operation = OperadorPicker.SelectedItem.ToString();

            switch (operation)
            {
                case "Soma":
                    result = firstOperand + secondOperand;
                    break;
                case "Subtra��o":
                    result = firstOperand - secondOperand;
                    break;
                case "Multiplica��o":
                    result = firstOperand * secondOperand;
                    break;
                case "Divis�o":
                    if (secondOperand != 0)
                        result = firstOperand / secondOperand;
                    else
                        resultLabel.Text = "Erro: Divis�o por zero!";
                    break;
            }

            resultLabel.Text = "Resultado: " + result.ToString();
        }
        else
        {
            resultLabel.Text = "Erro: Insira valorescv�lidos!";
        } 

    }
}