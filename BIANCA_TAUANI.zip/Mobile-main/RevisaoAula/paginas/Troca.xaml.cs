namespace RevisaoAula.paginas;

public partial class Troca : ContentPage
{
	public Troca()
	{
		InitializeComponent();
	}
    public void Voltar(object sender, EventArgs e)
    {
        App.Current.MainPage=new Page1();
    }

    private void Trocar(object sender, EventArgs e)
    {
        string oldPalavra = txtOldPalavra.Text;
        string newPalavra = txtNovaPalavra.Text;
        string Completo = txtCompleto.Text;

        string result = Completo.Replace(oldPalavra, newPalavra);
        lblResult.Text = result;
    }
   }