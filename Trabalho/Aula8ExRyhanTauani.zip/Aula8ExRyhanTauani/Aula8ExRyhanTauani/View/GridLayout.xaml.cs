
namespace Aula8ExRyhanTauani.View;

public partial class GridLayout : ContentPage
{
	public GridLayout()
	{
		InitializeComponent();
	}
}