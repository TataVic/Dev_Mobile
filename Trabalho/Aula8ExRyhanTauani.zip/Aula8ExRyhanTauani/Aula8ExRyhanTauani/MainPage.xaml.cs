﻿using System;
using Aula8ExRyhanTauani.View;
using Microsoft.Maui.Controls.Compatibility;

namespace Aula8ExRyhanTauani
{
    public partial class MainPage : ContentPage
    {

        public MainPage()
        {
            InitializeComponent();
        }

        private void Cliques(object sender, EventArgs e)
        {
            Navigation.PushAsync(new GridLayout());
        }
    }

}
